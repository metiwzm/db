from time import time
from datetime import datetime
from config import BOT_USERNAME, BOT_NAME, ASSISTANT_NAME, OWNER_NAME, UPDATES_CHANNEL, GROUP_SUPPORT
from helpers.filters import command
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from helpers.decorators import authorized_users_only


START_TIME = datetime.utcnow()
START_TIME_ISO = START_TIME.replace(microsecond=0).isoformat()
TIME_DURATION_UNITS = (
    ('week', 60 * 60 * 24 * 7),
    ('day', 60 * 60 * 24),
    ('hour', 60 * 60),
    ('min', 60),
    ('sec', 1)
)

async def _human_time_duration(seconds):
    if seconds == 0:
        return 'inf'
    parts = []
    for unit, div in TIME_DURATION_UNITS:
        amount, seconds = divmod(int(seconds), div)
        if amount > 0:
            parts.append('{} {}{}'
                         .format(amount, unit, "" if amount == 1 else "s"))
    return ', '.join(parts)


@Client.on_message(command("start") & filters.private & ~filters.edited)
async def start_(client: Client, message: Message):
    await message.reply_text(
        f"""<b>✨ **Welcome {message.from_user.first_name}** \n
💭 **[{BOT_NAME}](https://t.me/{BOT_USERNAME}) به شما این امکان را میدهد تا در گروه یا کانال خود آهنگ پخش کنید!**

💡 **برای اطلاع از دستورات ربات دکمه » 📚 دستورات رو چک کنید !**

❓ **برای اطلاع از تمامی دستور های ربات, دستور /help را ارسال کنید**
</b>""",
        reply_markup=InlineKeyboardMarkup(
            [ 
                [
                    InlineKeyboardButton(
                        "➕ منو به گروه خودت اضافه کن ➕", url=f"https://t.me/{BOT_USERNAME}?startgroup=true")
                ],[
                    InlineKeyboardButton(
                         "📚 دستورات", url="https://telegra.ph/Makhusic-Fa-08-20"
                    ),
                    InlineKeyboardButton(
                        "💝 سازنده", url=f"https://t.me/{OWNER_NAME}")
                ],[
                    InlineKeyboardButton(
                        "👥 گروه پشتیبانی", url=f"https://t.me/{GROUP_SUPPORT}"
                    ),
                    InlineKeyboardButton(
                        "📣 کانال رسمی", url=f"https://t.me/{UPDATES_CHANNEL}")
                ],[
                    InlineKeyboardButton(
                        "🌐 وبسایت", url="http://mahify.ga")
                ]
            ]
        ),
     disable_web_page_preview=True
    )


@Client.on_message(command(["start", f"start@{BOT_USERNAME}"]) & filters.group & ~filters.edited)
async def start(client: Client, message: Message):
    current_time = datetime.utcnow()
    uptime_sec = (current_time - START_TIME).total_seconds()
    uptime = await _human_time_duration(int(uptime_sec))
    await message.reply_text(
        f"""✅ **ربات روشن است**\n<b>💠 **آپ تایم:**</b> `{uptime}`""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "✨ گروه", url=f"https://t.me/{GROUP_SUPPORT}"
                    ),
                    InlineKeyboardButton(
                        "📣 کانال", url=f"https://t.me/{UPDATES_CHANNEL}"
                    )
                ]
            ]
        )
    )

@Client.on_message(command(["help", f"help@{BOT_USERNAME}"]) & filters.group & ~filters.edited)
async def help(client: Client, message: Message):
    await message.reply_text(
        f"""<b>👋🏻 سلام {message.from_user.mention()}, برای اینکه بفهمی چطوری از من استفاده کنی بزن روی دکمه زیر</b>""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        text="❔ چطور", url=f"https://t.me/{BOT_USERNAME}?start=help"
                    )
                ]
            ]
        )
    )

@Client.on_message(command("help") & filters.private & ~filters.edited)
async def help_(client: Client, message: Message):
    await message.reply_text(
        f"""<b>سلام {message.from_user.mention()}, به منوی راهنما خوش اومدی ✨
\n📙 نحو استفاده از من
\n1. اول من رو به گروهت اضافه کن.
2. ادمینم کن و همه قابلیتا رو بهم بده.
3. بعدش @{ASSISTANT_NAME} رو اضافه کن یا بنویس /userbotjoin.
3. یادت نره قبل اینکه بخوای آهنگ پخش کنی وویس چت گروه روشن باشه.
\n💁🏻‍♀️ **دستور برای همه کاربران:**
\n/play (نام آهنگ) - پخش آهنگ درخواستی در صورت وجود در یوتیوب
/stream (ریپلای به فایل mp3) - پخش فایل mp3
/playlist - لیست پخش
/current - آهنگ در حال پخش
/song (نام آهنگ) - آپلود آهنگ در صورت وجود در یوتیوب
/search (اسم ویدئو) - سرچ ویدئو در یوتیوب
/vsong (اسم ویدئو) - دانلود ویدئو در صورت وجود در یوتیوب
\n👷🏻‍♂️ **دستور برای ادمین ها:**
\n/player - باز کردن منوی انظیمات پلیر
/pause - متوقف کردن آهنگ در حال پخش
/resume - ادامه یافتن آهنگ متوقف شده
/skip - رد کردن آهنگ فعلی
/end - تمام شدن پخش آهنگ
/userbotjoin - اضافه کردن پلیر به گروه
/reload -  تازه سازی لیست ادمین ها
/auth - مجاز کردن کاربر از ربات
/deauth - مسدود کردن کاربر از ربات
\n🎊 **دستورات اضافه:**
\n/lyric (اسم آهنگ) - پیدا کردن متن آهنگ
</b>""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "✨ گروه", url=f"https://t.me/{GROUP_SUPPORT}"
                    ),
                    InlineKeyboardButton(
                        "📣 کانال", url=f"https://t.me/{UPDATES_CHANNEL}"
                    )
                ],
                [
                    InlineKeyboardButton(
                        "👩🏻‍💻 سازنده", url=f"https://t.me/{OWNER_NAME}"
                    )
                ]
            ]
        )
    )


@Client.on_message(command(["ping", f"ping@{BOT_USERNAME}"]) & ~filters.edited)
async def ping_pong(client: Client, message: Message):
    start = time()
    m_reply = await message.reply_text("گرفتن پینگ...")
    delta_ping = time() - start
    await m_reply.edit_text(
        "🏓 `PONG!!`\n"
        f"⚡️ `{delta_ping * 1000:.3f} ms`"
    )


@Client.on_message(command(["uptime", f"uptime@{BOT_USERNAME}"]) & ~filters.edited)
@authorized_users_only
async def get_uptime(client: Client, message: Message):
    current_time = datetime.utcnow()
    uptime_sec = (current_time - START_TIME).total_seconds()
    uptime = await _human_time_duration(int(uptime_sec))
    await message.reply_text(
        "🤖 وضعیت ربات:\n"
        f"• **آپ تایم:** `{uptime}`\n"
        f"• **استارت تایم:** `{START_TIME_ISO}`"
    )
