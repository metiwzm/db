
import os
from config import OWNER_NAME, UPDATES_CHANNEL, GROUP_SUPPORT, BOT_NAME, DEV_NAME
class Messages():
  INFO_MSG = [
    ".",
f"""
**󠁧󠁢󠁥󠁮󠁧󠁿✨ پنل اطلاعات ربات {BOT_NAME} ✨ \n
💭 این ربات توسط مهبا جهت پخش آهنگ در وویس چت گروه یا کانال ها ساخته شده است!\n
💠 اگر شما هم میخواهید چنین رباتی داشته باشید با سازنده ربات در ارتباط باشید :)\n
👩🏻‍💻 سازنده:
❍ @{DEV_NAME}
❍ @{OWNER_NAME}\n
💬 گروه پشتیبانی:
❍ @{GROUP_SUPPORT}
📣 کانال آپدیت ها:
❍ @{UPDATES_CHANNEL}\n
💝 حمایت مالی:
⊛ شما می‌توانید از طریق این لینک از سازنده ربات حمایت کنید: https://idpay.ir/M4hbod**
"""
  ]
